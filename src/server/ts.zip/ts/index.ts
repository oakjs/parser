import bodyParser from "body-parser"
import express, { Request, Response } from 'express';
import express_json5 from "express-json5"
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

import { api } from "./api.ts"


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3001;

// Add JSON / JSON5 body parser support
app.use(express_json5())

// Set up body parsers for text, json and form-urlencoded
app.use(bodyParser.text({ limit: "10mb" }))
app.use(bodyParser.json({ limit: "10mb" }))
app.use(bodyParser.urlencoded({ extended: true, limit: "10mb" }))


// API routes
app.get('/hello', (request:Request, response:Response) => {
  response.json({ message: 'Hello from the API!' });
});

// Use our api routines under `/api/...`
app.use("/api", api)


// Serve static files from the dist directory
app.use('/static', express.static(join(__dirname, '../../dist')));

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
}); 